from django.contrib import admin
from eshopapp.models import Product

# Register your models here.

# admin.site.register(Product) # when we are not having product admin class

class ProductAdmin(admin.ModelAdmin):
    list_display=['id','name','price','details','cat','isActive']
    list_filter=['cat','price','isActive']

admin.site.register(Product,ProductAdmin)