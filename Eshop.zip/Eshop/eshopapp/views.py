from django.shortcuts import render,HttpResponse,redirect
from django.views import View
from django.contrib.auth.models import User
from django.contrib.auth import authenticate,login,logout
from eshopapp.models import Product,Cart,Order
from django.db.models import Q
import random
import razorpay
from django.core.mail import send_mail


# Create your views here.

def about(request):
    context={}
    context['title'] = " Flavourful BITES | About Us"
    return render(request,'about.html',context)

def register(request):
    context={}
    context['title'] = " Flavourful BITES | Register"

    if request.method == "POST":
        uname = request.POST['uname']
        upass = request.POST['upass']
        ucpass = request.POST['ucpass']

        if uname == "" or upass == "" or ucpass == "" :
            context['errmsg']="Fields can not be blank"
            return render (request,'register.html',context)
        elif upass!=ucpass:
            context['errmsg']="Password and Confirm Password didn't match"
            return render (request,'register.html',context)
        else:
            try:
                u= User.objects.create(username=uname,email=uname)
                u.set_password(upass)
                u.save()
                context['success']="User Created Successfully , please login!! "
                return render (request,'register.html',context)
            except Exception:
                context['errmsg']="Username is already exist, please try another"
                return render (request,'register.html',context)
    else:
        return render (request,'register.html')


def user_login(request):  #always use different function name..dont match wt inbuilt, imported functions name
    context={}
    context['title'] = "Flavourful BITES | Login"
    
    if request.method == "POST":
         uname = request.POST['uname']
         upass = request.POST['upass']
        #  print(uname,upass)
         if uname == "" or upass == "":
            context['errmsg']="Fields can not be blank"
            return render (request,'login.html',context)
         else:
            u= authenticate(username=uname,password=upass)
            # print(u)
            # print(u.password)
            if u is not None:   #firstuser@gmail.com is not none = true
                login(request,u)  #start session and store id of looged in user.
                return redirect ('/')
            else:
                context['errmsg']="Invalid username and password "
                return render (request,'login.html',context)
    else:
        return render (request,'login.html')

def user_logout(request):
    logout(request)
    return redirect ('/')


def home(request):
    # userId = request.user.id
    # print("loggedin user",userId)
    # print(request.user.is_authenticated)
    context={}
    context['title'] = "Flavourful BITES | Home"
    x= Product.objects.filter(isActive=1)
    # print(x)
    context['data'] = x
    return render (request,'index.html',context)

def catfilter(request,cv):  
    c1=Q(cat=cv )
    c2=Q(isActive=1)
    x=Product.objects.filter(c1 & c2)
    context={}
    context['data']=x
    return render (request,'index.html',context)

def sortfilter(request,sv):
    if sv == '0':
        col ='price'
    else:
       col = '-price'
    x=Product.objects.filter(isActive=1).order_by(col)
    context={}
    context['data']=x
    return render (request,'index.html',context)

def range(request):
    min=request.GET['min']
    max=request.GET['max']
    q1=Q(price__gte=min)
    q2=Q(price__lte=max)
    q3=Q(isActive=1)
    x=Product.objects.filter(q1 & q2 & q3)
    context={}
    context['data']=x
    return render (request,'index.html',context)


def product_details(request,rid):

    x= Product.objects.filter(id=rid)
    context={}
    context['title'] = "Flavourful BITES | Product Details"
    context['data']=x
    return render (request,'product_details.html',context)


def addtocart(request,pid):
    if request.user.is_authenticated:  # if logged in / session is started
        context={}
        context['title'] = "Flavourful BITES | Add to Cart"
        userid=request.user.id  #id of logged in user from session
        # print(pid) # product id
        # print(userid) # user id who logged in
        u=User.objects.filter(id=userid)
        # print(u[0])  #  becoz it returns the query list, thts why we using index position
        p=Product.objects.filter(id=pid)
        # print(p[0])  # becoz it returns the query list, thts why we using index position
        q1=Q(uid = u[0])
        q2=Q(pid = p[0])
        x= Cart.objects.filter( q1 & q2 )
        print(x)
        n=len(x)
        
        context['data']= p
        if n == 1:
            context['msg']="Product is already exists in the cart !!"
        else:
            c = Cart.objects.create(uid=u[0],pid=p[0])
            c.save()
            context['successmsg'] = "Product Added in to the cart !!"

        return render (request,'product_details.html',context)
    else:
        return redirect ('/login')

def viewcart(request):
    userid=request.user.id
    c = Cart.objects.filter(uid = userid)
    # print(c)
    # print(c[0])
    # print(c[0].pid)
    # print("Name",c[0].pid.name)
    # print("price",c[0].pid.price)
    # print("Username",c[0].uid.username)
    s=0
    np=len(c)
    # print(np)
    for x in c:
        # print(x)
        # print(x.pi.price)
        s= s + x.pid.price * x.qty
    # print(s)
    context={}
    context['Product']=c
    context['total']=s
    context['qty']=np
    context['title'] = "Flavourful BITES | My Cart"
    return render (request,'cart.html',context)


def delete(request,cid):
    x=Cart.objects.filter(id=cid)
    x.delete()
    return redirect ('/viewcart')

def updateqty(request,qv,cid):
    # print (type(rid))
    x=Cart.objects.filter(id=cid)
    # print(x)
    # print(x[0])
    # print(x[0].qty)
    if qv == '1':
        t=x[0].qty + 1
        # print(t)
        # print(x[0])
        x.update(qty=t)
    else:
        if x[0].qty > 1:
            t = x[0].qty - 1
            x.update(qty=t)
            
    return redirect ('/viewcart')

def placeorder(request):
    userid= request.user.id
    c=Cart.objects.filter(uid=userid)
    oid=random.randrange(1000,9999)
    # print(oid)
    # print(oid)
    for x in c:
        # print(x)
        # print(x.pid)
        # print(x.uid)
        # print(x.qty)
        o= Order.objects.create(order_id=oid,pid=x.pid,uid=x.uid,qty=x.qty) #shifting cart data to order table
        o.save()
        x.delete() # deleting  viewcart data

    orders=Order.objects.filter(uid=request.user.id) # displaying order table data
    s=0 
    np=len(orders) # for qty
    for x in orders:
        s= s + x.pid.price * x.qty  #0+100*2=200+350*3=1250+117*2=1484+100*1 = 1584
    context={}
    context['Product']=orders
    context['total']= s
    context['qty']=np
    context['title'] = "Flavourful BITES | My Orders"
    return render(request,"placeorder.html",context)

def makepayment(request):
    
    uemail=request.user.email  # when we making payment after tht session get logged out so we r passing email id to pa.html page
    # print(uemail)

    orders=Order.objects.filter(uid=request.user.id) # displaying order table data
    s=0
    for x in orders:
        s= s + x.pid.price * x.qty
        oid=x.order_id

    client = razorpay.Client(auth=("rzp_test_JCj8WridGC8RKj", "ZngLleIucg0rxoObPrqxHciI"))
    data = { "amount": s*100, "currency": "INR", "receipt": oid }
    payment = client.order.create(data=data)
    context={}
    context['uemail']=uemail # pasing email to send usermail function
    context['data']=payment
    context['title'] = "Flavourful BITES | Make Payment"
    # print(payment)
    return render(request,'pay.html',context)

def sendusermail(request,uemail):
    
    orders=Order.objects.filter(uid=request.user.id)
    # print(orders)
    for x in orders:
        oid=x.order_id
        pname = x.pid.name
        x.delete()
        
    # print(orders)
    # uemail=request.user.email
    print(uemail)
    msg=" Dear Customer Your Order Details :" 
    
    send_mail(
    "Flavourful BITES - Your Order placed Successfully",
    msg,
    "bhaktishan10@gmail.com",
    [uemail],
    fail_silently=False,
)
    return redirect ('/orderdone')

def orderdone(request):
    return render (request,'orderdone.html')
